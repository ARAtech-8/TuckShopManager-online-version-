-- =====================================================================================
-- Tuck Shop Manager: Supabase database setup
-- Paste this whole file into Supabase > SQL Editor > New query > Run.
-- Safe to run once on a new project. (To rebuild from scratch, see the README.)
--
-- Privacy rules enforced HERE on the server (not just hidden in the app):
--   Owner    : sees and changes everything in their shop.
--   Employee : can see products (name, category, selling price, stock), customer names,
--              and ONLY their own sales from the last 2 days. Can sell, cancel their own
--              recent sale, and report lost stock. Can NOT read cost prices, profit,
--              expenses, supplier or owner money, reports, other staff, or the activity log.
-- All writes go through the functions below; the tables cannot be written to directly.
-- =====================================================================================

create or replace function public.now_ms() returns bigint
language sql stable as $$ select (extract(epoch from clock_timestamp()) * 1000)::bigint $$;

-- ------------------------------------------------------------------------------ tables
create table if not exists public.shops (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  symbol text not null default '$',
  opening_money numeric not null default 0,
  license_key text,
  allow_employee_credit boolean not null default true,
  migrated_at bigint,
  created_at bigint not null default public.now_ms()
);

create table if not exists public.members (
  user_id uuid primary key references auth.users(id) on delete cascade,
  shop_id uuid not null references public.shops(id) on delete cascade,
  role text not null check (role in ('owner','employee')),
  username text not null,
  display_name text not null,
  active boolean not null default true,
  created_at bigint not null default public.now_ms(),
  unique (shop_id, username)
);

create table if not exists public.products (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops(id) on delete cascade,
  name text not null,
  category text not null default 'General',
  unit text not null default 'each',
  sell_price numeric not null default 0,
  stock_qty numeric not null default 0,
  reorder_level numeric not null default 5,
  active boolean not null default true,
  created_at bigint not null default public.now_ms()
);
create unique index if not exists products_shop_name_active
  on public.products (shop_id, lower(name)) where active;

create table if not exists public.product_costs (
  product_id bigint primary key references public.products(id) on delete cascade,
  shop_id uuid not null references public.shops(id) on delete cascade,
  cost_price numeric not null default 0
);

create table if not exists public.customers (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops(id) on delete cascade,
  name text not null,
  phone text not null default '',
  created_at bigint not null default public.now_ms()
);

create table if not exists public.sales (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops(id) on delete cascade,
  time bigint not null default public.now_ms(),
  total numeric not null default 0,
  method text not null check (method in ('CASH','MOBILE','CREDIT')),
  customer_id bigint,
  note text not null default '',
  voided boolean not null default false,
  created_by uuid,
  created_by_name text not null default '',
  voided_by_name text,
  voided_at bigint
);
create index if not exists sales_shop_time on public.sales (shop_id, time);
create index if not exists sales_created_by on public.sales (created_by, time);

create table if not exists public.sale_items (
  id bigint generated always as identity primary key,
  sale_id bigint not null references public.sales(id) on delete cascade,
  shop_id uuid not null references public.shops(id) on delete cascade,
  product_id bigint not null,
  name text not null,
  qty numeric not null,
  unit_price numeric not null
);
create index if not exists sale_items_sale on public.sale_items (sale_id);

-- Cost of each sold item lives in its own table so employees can never read it.
create table if not exists public.sale_costs (
  sale_item_id bigint primary key references public.sale_items(id) on delete cascade,
  shop_id uuid not null references public.shops(id) on delete cascade,
  unit_cost numeric not null default 0
);

create table if not exists public.restocks (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops(id) on delete cascade,
  time bigint not null default public.now_ms(),
  product_id bigint not null,
  product_name text not null,
  qty numeric not null,
  unit_cost numeric not null,
  supplier text not null default '',
  paid_now numeric not null default 0,
  created_by_name text not null default ''
);
create table if not exists public.supplier_payments (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops(id) on delete cascade,
  time bigint not null default public.now_ms(),
  supplier text not null,
  amount numeric not null,
  note text not null default ''
);
create table if not exists public.adjustments (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops(id) on delete cascade,
  time bigint not null default public.now_ms(),
  product_id bigint not null,
  product_name text not null,
  qty_change numeric not null,
  unit_cost numeric not null,
  reason text not null,
  created_by_name text not null default ''
);
create table if not exists public.expenses (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops(id) on delete cascade,
  time bigint not null default public.now_ms(),
  category text not null,
  amount numeric not null,
  note text not null default ''
);
create table if not exists public.owner_txns (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops(id) on delete cascade,
  time bigint not null default public.now_ms(),
  amount numeric not null,
  note text not null default ''
);
create table if not exists public.customer_payments (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops(id) on delete cascade,
  customer_id bigint not null,
  time bigint not null default public.now_ms(),
  amount numeric not null,
  note text not null default ''
);
create table if not exists public.activity_log (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops(id) on delete cascade,
  time bigint not null default public.now_ms(),
  user_name text not null,
  action text not null,
  detail text not null default ''
);
create index if not exists activity_shop_time on public.activity_log (shop_id, time desc);

-- ------------------------------------------------------------------------- who is asking
create or replace function public.current_shop() returns uuid
language sql stable security definer set search_path = public as $$
  select shop_id from public.members where user_id = auth.uid() and active limit 1 $$;

create or replace function public.is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.members where user_id = auth.uid() and active and role = 'owner') $$;

create or replace function public._ctx() returns public.members
language plpgsql stable security definer set search_path = public as $$
declare m public.members;
begin
  select * into m from public.members where user_id = auth.uid() and active;
  if not found then
    raise exception 'Your account is not active for any shop.' using errcode = '42501';
  end if;
  return m;
end $$;

create or replace function public._owner() returns public.members
language plpgsql stable security definer set search_path = public as $$
declare m public.members;
begin
  m := public._ctx();
  if m.role <> 'owner' then
    raise exception 'Only the shop owner can do this.' using errcode = '42501';
  end if;
  return m;
end $$;

create or replace function public._log(p_shop uuid, p_name text, p_action text, p_detail text)
returns void language sql security definer set search_path = public as $$
  insert into public.activity_log (shop_id, user_name, action, detail) values (p_shop, p_name, p_action, coalesce(p_detail, '')) $$;

-- ---------------------------------------------------------------------- row level security
alter table public.shops enable row level security;
alter table public.members enable row level security;
alter table public.products enable row level security;
alter table public.product_costs enable row level security;
alter table public.customers enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.sale_costs enable row level security;
alter table public.restocks enable row level security;
alter table public.supplier_payments enable row level security;
alter table public.adjustments enable row level security;
alter table public.expenses enable row level security;
alter table public.owner_txns enable row level security;
alter table public.customer_payments enable row level security;
alter table public.activity_log enable row level security;

drop policy if exists shops_read on public.shops;
create policy shops_read on public.shops for select to authenticated
  using (id = public.current_shop());

drop policy if exists members_read on public.members;
create policy members_read on public.members for select to authenticated
  using (shop_id = public.current_shop() and (public.is_owner() or user_id = auth.uid()));

drop policy if exists products_read on public.products;
create policy products_read on public.products for select to authenticated
  using (shop_id = public.current_shop());

drop policy if exists customers_read on public.customers;
create policy customers_read on public.customers for select to authenticated
  using (shop_id = public.current_shop());

drop policy if exists sales_read on public.sales;
create policy sales_read on public.sales for select to authenticated
  using (shop_id = public.current_shop()
         and (public.is_owner() or (created_by = auth.uid() and time > public.now_ms() - 172800000)));

drop policy if exists sale_items_read on public.sale_items;
create policy sale_items_read on public.sale_items for select to authenticated
  using (shop_id = public.current_shop()
         and exists (select 1 from public.sales s where s.id = sale_id));

-- owner-only tables
do $$
declare t text;
begin
  foreach t in array array['product_costs','sale_costs','restocks','supplier_payments','adjustments',
                           'expenses','owner_txns','customer_payments','activity_log'] loop
    execute format('drop policy if exists %I on public.%I', t || '_owner_read', t);
    execute format('create policy %I on public.%I for select to authenticated using (shop_id = public.current_shop() and public.is_owner())',
                   t || '_owner_read', t);
  end loop;
end $$;

-- ------------------------------------------------------------------------- shop and staff
create or replace function public.create_shop(p_name text, p_display_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_code text; v_id uuid; v_alpha text := '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; i int;
begin
  if auth.uid() is null then raise exception 'Please sign in first.' using errcode = '42501'; end if;
  if exists (select 1 from public.members where user_id = auth.uid()) then
    raise exception 'This account already belongs to a shop.';
  end if;
  if coalesce(trim(p_name), '') = '' then raise exception 'Please type a shop name.'; end if;
  loop
    v_code := '';
    for i in 1..6 loop
      v_code := v_code || substr(v_alpha, 1 + floor(random() * 32)::int, 1);
    end loop;
    exit when not exists (select 1 from public.shops where code = v_code);
  end loop;
  insert into public.shops (code, name) values (v_code, trim(p_name)) returning id into v_id;
  insert into public.members (user_id, shop_id, role, username, display_name)
    values (auth.uid(), v_id, 'owner', 'owner', coalesce(nullif(trim(p_display_name), ''), 'Owner'));
  return v_id;
end $$;

create or replace function public.update_shop(p_name text, p_symbol text, p_opening numeric, p_allow_credit boolean)
returns void language plpgsql security definer set search_path = public as $$
declare m public.members;
begin
  m := public._owner();
  update public.shops set name = coalesce(nullif(trim(p_name), ''), name),
         symbol = coalesce(nullif(trim(p_symbol), ''), symbol),
         opening_money = coalesce(p_opening, opening_money),
         allow_employee_credit = coalesce(p_allow_credit, allow_employee_credit)
   where id = m.shop_id;
  perform public._log(m.shop_id, m.display_name, 'Shop settings changed', '');
end $$;

create or replace function public.set_license_key(p_key text) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members;
begin
  m := public._owner();
  update public.shops set license_key = nullif(trim(p_key), '') where id = m.shop_id;
end $$;

-- The app creates the staff login in Supabase Auth first, then calls this to attach it to the shop.
create or replace function public.add_member(p_user uuid, p_email text, p_username text, p_display_name text)
returns void language plpgsql security definer set search_path = public as $$
declare m public.members; v_code text;
begin
  m := public._owner();
  select code into v_code from public.shops where id = m.shop_id;
  if not exists (select 1 from auth.users u where u.id = p_user and lower(u.email) = lower(p_email)) then
    raise exception 'That login was not found. Please try again.';
  end if;
  if lower(p_email) not like 'tsm.' || lower(v_code) || '.%' then
    raise exception 'That login does not belong to this shop.';
  end if;
  if exists (select 1 from public.members where user_id = p_user) then
    raise exception 'That login is already in use.';
  end if;
  insert into public.members (user_id, shop_id, role, username, display_name)
    values (p_user, m.shop_id, 'employee', lower(trim(p_username)), coalesce(nullif(trim(p_display_name), ''), p_username));
  perform public._log(m.shop_id, m.display_name, 'Employee added', coalesce(p_display_name, p_username));
end $$;

create or replace function public.set_member_active(p_user uuid, p_active boolean) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members; t public.members;
begin
  m := public._owner();
  select * into t from public.members where user_id = p_user and shop_id = m.shop_id and role = 'employee';
  if not found then raise exception 'Employee not found.'; end if;
  update public.members set active = p_active where user_id = p_user;
  perform public._log(m.shop_id, m.display_name,
    case when p_active then 'Employee re-enabled' else 'Employee disabled' end, t.display_name);
end $$;

-- ----------------------------------------------------------------------------- products
create or replace function public.save_product(p_id bigint, p_name text, p_category text, p_unit text,
  p_cost numeric, p_sell numeric, p_qty numeric, p_reorder numeric) returns bigint
language plpgsql security definer set search_path = public as $$
declare m public.members; v_id bigint; old public.products; oldcost numeric;
begin
  m := public._owner();
  if coalesce(trim(p_name), '') = '' then raise exception 'Please type a product name.'; end if;
  begin
    if p_id is null or p_id = 0 then
      insert into public.products (shop_id, name, category, unit, sell_price, stock_qty, reorder_level)
        values (m.shop_id, trim(p_name), coalesce(nullif(trim(p_category), ''), 'General'),
                coalesce(nullif(trim(p_unit), ''), 'each'), coalesce(p_sell, 0), coalesce(p_qty, 0), coalesce(p_reorder, 5))
        returning id into v_id;
      insert into public.product_costs (product_id, shop_id, cost_price) values (v_id, m.shop_id, coalesce(p_cost, 0));
    else
      select * into old from public.products where id = p_id and shop_id = m.shop_id;
      if not found then raise exception 'Product not found.'; end if;
      select cost_price into oldcost from public.product_costs where product_id = p_id;
      update public.products set name = trim(p_name), category = coalesce(nullif(trim(p_category), ''), 'General'),
             unit = coalesce(nullif(trim(p_unit), ''), 'each'), sell_price = coalesce(p_sell, 0),
             reorder_level = coalesce(p_reorder, 5)
       where id = p_id;
      insert into public.product_costs (product_id, shop_id, cost_price) values (p_id, m.shop_id, coalesce(p_cost, 0))
        on conflict (product_id) do update set cost_price = excluded.cost_price;
      v_id := p_id;
      if old.sell_price is distinct from coalesce(p_sell, 0) or oldcost is distinct from coalesce(p_cost, 0) then
        perform public._log(m.shop_id, m.display_name, 'Price changed', trim(p_name));
      end if;
    end if;
  exception when unique_violation then
    raise exception 'You already have a product called "%".', trim(p_name);
  end;
  return v_id;
end $$;

create or replace function public.archive_product(p_id bigint) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members; n text;
begin
  m := public._owner();
  update public.products set active = false where id = p_id and shop_id = m.shop_id returning name into n;
  perform public._log(m.shop_id, m.display_name, 'Product deleted', coalesce(n, ''));
end $$;

-- Excel/CSV import. Each row: name, category, unit, cost, sell, qty, reorder (null = "not in the file").
create or replace function public.import_products(p_rows jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare m public.members; r jsonb; ex public.products; v_added int := 0; v_updated int := 0; v_id bigint;
begin
  m := public._owner();
  for r in select * from jsonb_array_elements(p_rows) loop
    select * into ex from public.products where shop_id = m.shop_id and active and lower(name) = lower(trim(r->>'name'));
    if not found then
      insert into public.products (shop_id, name, category, unit, sell_price, stock_qty, reorder_level)
        values (m.shop_id, trim(r->>'name'), coalesce(nullif(trim(r->>'category'), ''), 'General'),
                coalesce(nullif(trim(r->>'unit'), ''), 'each'), coalesce((r->>'sell')::numeric, 0),
                coalesce((r->>'qty')::numeric, 0), coalesce((r->>'reorder')::numeric, 5))
        returning id into v_id;
      insert into public.product_costs (product_id, shop_id, cost_price) values (v_id, m.shop_id, coalesce((r->>'cost')::numeric, 0));
      v_added := v_added + 1;
    else
      update public.products set category = coalesce(nullif(trim(r->>'category'), ''), ex.category),
             unit = coalesce(nullif(trim(r->>'unit'), ''), ex.unit),
             sell_price = coalesce((r->>'sell')::numeric, ex.sell_price),
             stock_qty = coalesce((r->>'qty')::numeric, ex.stock_qty),
             reorder_level = coalesce((r->>'reorder')::numeric, ex.reorder_level)
       where id = ex.id;
      if (r->>'cost') is not null then
        insert into public.product_costs (product_id, shop_id, cost_price) values (ex.id, m.shop_id, (r->>'cost')::numeric)
          on conflict (product_id) do update set cost_price = excluded.cost_price;
      end if;
      v_updated := v_updated + 1;
    end if;
  end loop;
  perform public._log(m.shop_id, m.display_name, 'Product list imported', v_added || ' added, ' || v_updated || ' updated');
  return jsonb_build_object('added', v_added, 'updated', v_updated);
end $$;

-- ------------------------------------------------------------------------------- selling
create or replace function public.create_sale(p_lines jsonb, p_method text, p_customer bigint, p_note text)
returns bigint language plpgsql security definer set search_path = public as $$
declare m public.members; v_sale bigint; l jsonb; p public.products; v_price numeric; v_qty numeric;
        v_total numeric := 0; v_cost numeric; v_item bigint;
begin
  m := public._ctx();
  if p_method not in ('CASH','MOBILE','CREDIT') then raise exception 'Bad payment method.'; end if;
  if p_lines is null or jsonb_typeof(p_lines) <> 'array' or jsonb_array_length(p_lines) = 0 then
    raise exception 'The sale is empty.';
  end if;
  if p_method = 'CREDIT' then
    if p_customer is null or not exists (select 1 from public.customers where id = p_customer and shop_id = m.shop_id) then
      raise exception 'Please choose a customer for a credit sale.';
    end if;
    if m.role <> 'owner' and not (select allow_employee_credit from public.shops where id = m.shop_id) then
      raise exception 'The owner has not allowed staff to sell on credit.';
    end if;
  end if;
  insert into public.sales (shop_id, total, method, customer_id, note, created_by, created_by_name)
    values (m.shop_id, 0, p_method, case when p_method = 'CREDIT' then p_customer end,
            coalesce(p_note, ''), m.user_id, m.display_name)
    returning id into v_sale;
  for l in select * from jsonb_array_elements(p_lines) loop
    v_qty := (l->>'qty')::numeric;
    if v_qty is null or v_qty <= 0 then raise exception 'Bad quantity in the sale.'; end if;
    select * into p from public.products
      where id = (l->>'product_id')::bigint and shop_id = m.shop_id and active for update;
    if not found then raise exception 'An item in this sale is no longer in your product list.'; end if;
    v_price := p.sell_price;
    if m.role = 'owner' and (l->>'price') is not null then v_price := (l->>'price')::numeric; end if;
    if v_price < 0 then raise exception 'Bad price in the sale.'; end if;
    v_cost := null;
    select cost_price into v_cost from public.product_costs where product_id = p.id;
    insert into public.sale_items (sale_id, shop_id, product_id, name, qty, unit_price)
      values (v_sale, m.shop_id, p.id, p.name, v_qty, v_price) returning id into v_item;
    insert into public.sale_costs (sale_item_id, shop_id, unit_cost) values (v_item, m.shop_id, coalesce(v_cost, 0));
    update public.products set stock_qty = stock_qty - v_qty where id = p.id;
    v_total := v_total + v_qty * v_price;
  end loop;
  update public.sales set total = v_total where id = v_sale;
  return v_sale;
end $$;

create or replace function public.void_sale(p_id bigint) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members; s public.sales;
begin
  m := public._ctx();
  select * into s from public.sales where id = p_id and shop_id = m.shop_id for update;
  if not found then raise exception 'Sale not found.'; end if;
  if s.voided then return; end if;
  if m.role <> 'owner' then
    if s.created_by is distinct from m.user_id then
      raise exception 'You can only cancel sales that you made yourself.';
    end if;
    if public.now_ms() - s.time > 86400000 then
      raise exception 'Staff can only cancel a sale within 24 hours. Please ask the owner.';
    end if;
  end if;
  update public.sales set voided = true, voided_by_name = m.display_name, voided_at = public.now_ms() where id = p_id;
  update public.products p set stock_qty = p.stock_qty + x.q
    from (select product_id, sum(qty) q from public.sale_items where sale_id = p_id group by product_id) x
   where p.id = x.product_id and p.shop_id = m.shop_id;
  perform public._log(m.shop_id, m.display_name, 'Sale cancelled',
    'Sale of ' || s.total || ' made by ' || s.created_by_name);
end $$;

-- --------------------------------------------------------------------------------- stock
create or replace function public.restock(p_product bigint, p_qty numeric, p_unit_cost numeric, p_supplier text, p_paid_now numeric)
returns void language plpgsql security definer set search_path = public as $$
declare m public.members; p public.products; oldcost numeric; oldq numeric; newcost numeric;
begin
  m := public._owner();
  if p_qty is null or p_qty <= 0 then raise exception 'Please type how many you bought.'; end if;
  select * into p from public.products where id = p_product and shop_id = m.shop_id for update;
  if not found then raise exception 'Product not found.'; end if;
  select coalesce(cost_price, 0) into oldcost from public.product_costs where product_id = p.id;
  oldcost := coalesce(oldcost, 0);
  oldq := greatest(0, p.stock_qty);
  newcost := case when oldq + p_qty > 0 then (oldq * oldcost + p_qty * p_unit_cost) / (oldq + p_qty) else p_unit_cost end;
  insert into public.restocks (shop_id, product_id, product_name, qty, unit_cost, supplier, paid_now, created_by_name)
    values (m.shop_id, p.id, p.name, p_qty, p_unit_cost, coalesce(trim(p_supplier), ''),
            least(coalesce(p_paid_now, 0), p_qty * p_unit_cost), m.display_name);
  update public.products set stock_qty = stock_qty + p_qty where id = p.id;
  insert into public.product_costs (product_id, shop_id, cost_price) values (p.id, m.shop_id, newcost)
    on conflict (product_id) do update set cost_price = excluded.cost_price;
end $$;

create or replace function public.adjust_stock(p_product bigint, p_qty_change numeric, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members; p public.products; v_cost numeric;
begin
  m := public._ctx();
  if p_qty_change is null or p_qty_change = 0 then raise exception 'Nothing to change.'; end if;
  if m.role <> 'owner' then
    if p_qty_change > 0 then raise exception 'Staff can only remove stock. Ask the owner to add stock.'; end if;
    if p_reason not in ('Damaged','Expired','Missing or stolen','Used at home') then
      raise exception 'Please choose a reason from the list.';
    end if;
  end if;
  select * into p from public.products where id = p_product and shop_id = m.shop_id for update;
  if not found then raise exception 'Product not found.'; end if;
  select cost_price into v_cost from public.product_costs where product_id = p.id;
  insert into public.adjustments (shop_id, product_id, product_name, qty_change, unit_cost, reason, created_by_name)
    values (m.shop_id, p.id, p.name, p_qty_change, coalesce(v_cost, 0), p_reason, m.display_name);
  update public.products set stock_qty = stock_qty + p_qty_change where id = p.id;
  perform public._log(m.shop_id, m.display_name, 'Stock adjusted',
    p.name || ': ' || p_qty_change || ' (' || p_reason || ')');
end $$;

-- ----------------------------------------------------------------------- money and people
create or replace function public.add_customer(p_name text, p_phone text) returns bigint
language plpgsql security definer set search_path = public as $$
declare m public.members; v_id bigint;
begin
  m := public._ctx();
  if coalesce(trim(p_name), '') = '' then raise exception 'Please type the customer name.'; end if;
  insert into public.customers (shop_id, name, phone) values (m.shop_id, trim(p_name), coalesce(trim(p_phone), ''))
    returning id into v_id;
  return v_id;
end $$;

create or replace function public.add_expense(p_category text, p_amount numeric, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members;
begin
  m := public._owner();
  if p_amount is null or p_amount <= 0 then raise exception 'Please type an amount.'; end if;
  insert into public.expenses (shop_id, category, amount, note) values (m.shop_id, p_category, p_amount, coalesce(p_note, ''));
end $$;

create or replace function public.delete_expense(p_id bigint) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members;
begin
  m := public._owner();
  delete from public.expenses where id = p_id and shop_id = m.shop_id;
  perform public._log(m.shop_id, m.display_name, 'Expense deleted', '');
end $$;

create or replace function public.add_owner_txn(p_amount numeric, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members;
begin
  m := public._owner();
  if p_amount is null or p_amount = 0 then raise exception 'Please type an amount.'; end if;
  insert into public.owner_txns (shop_id, amount, note) values (m.shop_id, p_amount, coalesce(p_note, ''));
end $$;

create or replace function public.delete_owner_txn(p_id bigint) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members;
begin
  m := public._owner();
  delete from public.owner_txns where id = p_id and shop_id = m.shop_id;
end $$;

create or replace function public.receive_payment(p_customer bigint, p_amount numeric) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members;
begin
  m := public._owner();
  if p_amount is null or p_amount <= 0 then raise exception 'Please type an amount.'; end if;
  if not exists (select 1 from public.customers where id = p_customer and shop_id = m.shop_id) then
    raise exception 'Customer not found.';
  end if;
  insert into public.customer_payments (shop_id, customer_id, amount) values (m.shop_id, p_customer, p_amount);
end $$;

create or replace function public.pay_supplier(p_supplier text, p_amount numeric) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members;
begin
  m := public._owner();
  if p_amount is null or p_amount <= 0 then raise exception 'Please type an amount.'; end if;
  insert into public.supplier_payments (shop_id, supplier, amount) values (m.shop_id, coalesce(p_supplier, ''), p_amount);
end $$;

-- ---------------------------------------------------------------------------- reports (owner)
create or replace function public._net_money(p_shop uuid, p_from bigint, p_to bigint) returns numeric
language sql stable security definer set search_path = public as $$
  select
    coalesce((select sum(total) from public.sales where shop_id = p_shop and not voided and method <> 'CREDIT' and time >= p_from and time < p_to), 0)
  + coalesce((select sum(amount) from public.customer_payments where shop_id = p_shop and time >= p_from and time < p_to), 0)
  - coalesce((select sum(paid_now) from public.restocks where shop_id = p_shop and time >= p_from and time < p_to), 0)
  - coalesce((select sum(amount) from public.supplier_payments where shop_id = p_shop and time >= p_from and time < p_to), 0)
  - coalesce((select sum(amount) from public.expenses where shop_id = p_shop and time >= p_from and time < p_to), 0)
  + coalesce((select sum(amount) from public.owner_txns where shop_id = p_shop and amount > 0 and time >= p_from and time < p_to), 0)
  + coalesce((select sum(amount) from public.owner_txns where shop_id = p_shop and amount < 0 and time >= p_from and time < p_to), 0)
$$;

create or replace function public.report_lines(p_from bigint, p_to bigint) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare m public.members; r jsonb;
begin
  m := public._owner();
  select coalesce(jsonb_agg(jsonb_build_object(
           'sale_id', si.sale_id, 'product_id', si.product_id, 'name', si.name, 'qty', si.qty,
           'unit_price', si.unit_price, 'unit_cost', coalesce(c.unit_cost, 0),
           'time', s.time, 'method', s.method, 'staff', s.created_by_name)), '[]'::jsonb)
    into r
    from public.sale_items si
    join public.sales s on s.id = si.sale_id
    left join public.sale_costs c on c.sale_item_id = si.id
   where s.shop_id = m.shop_id and not s.voided and s.time >= p_from and s.time < p_to;
  return r;
end $$;

create or replace function public.report_sums(p_from bigint, p_to bigint) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare m public.members; v_open numeric;
begin
  m := public._owner();
  select opening_money into v_open from public.shops where id = m.shop_id;
  return jsonb_build_object(
    'sales_by_method', coalesce((select jsonb_agg(jsonb_build_object('name', method, 'amount', amt)) from
        (select method, sum(total) amt from public.sales where shop_id = m.shop_id and not voided and time >= p_from and time < p_to group by method) x), '[]'::jsonb),
    'expenses', coalesce((select jsonb_agg(jsonb_build_object('name', category, 'amount', amt) order by amt desc) from
        (select category, sum(amount) amt from public.expenses where shop_id = m.shop_id and time >= p_from and time < p_to group by category) x), '[]'::jsonb),
    'losses', coalesce((select jsonb_agg(jsonb_build_object('name', reason, 'amount', amt)) from
        (select reason, sum(-qty_change * unit_cost) amt from public.adjustments where shop_id = m.shop_id and time >= p_from and time < p_to group by reason) x), '[]'::jsonb),
    'restock_paid', coalesce((select sum(paid_now) from public.restocks where shop_id = m.shop_id and time >= p_from and time < p_to), 0),
    'restock_total', coalesce((select sum(qty * unit_cost) from public.restocks where shop_id = m.shop_id and time >= p_from and time < p_to), 0),
    'supplier_paid', coalesce((select sum(amount) from public.supplier_payments where shop_id = m.shop_id and time >= p_from and time < p_to), 0),
    'customer_paid', coalesce((select sum(amount) from public.customer_payments where shop_id = m.shop_id and time >= p_from and time < p_to), 0),
    'owner_in', coalesce((select sum(amount) from public.owner_txns where shop_id = m.shop_id and amount > 0 and time >= p_from and time < p_to), 0),
    'owner_out', coalesce((select -sum(amount) from public.owner_txns where shop_id = m.shop_id and amount < 0 and time >= p_from and time < p_to), 0),
    'opening_money', v_open + public._net_money(m.shop_id, 0, p_from),
    'money_now', v_open + public._net_money(m.shop_id, 0, public.now_ms() + 1)
  );
end $$;

create or replace function public.balances() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare m public.members;
begin
  m := public._owner();
  return jsonb_build_object(
    'customers', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'name', c.name, 'phone', c.phone,
        'owed', coalesce((select sum(total) from public.sales s where s.customer_id = c.id and s.shop_id = m.shop_id and not s.voided and s.method = 'CREDIT'), 0)
              - coalesce((select sum(amount) from public.customer_payments p where p.customer_id = c.id and p.shop_id = m.shop_id), 0))
        order by c.name) from public.customers c where c.shop_id = m.shop_id), '[]'::jsonb),
    'suppliers', coalesce((select jsonb_agg(jsonb_build_object('name', nm, 'owed', owed) order by owed desc) from
        (select coalesce(nullif(max(sup), ''), 'Supplier (no name)') nm, sum(owed) owed from
           (select trim(supplier) sup, lower(trim(supplier)) k, qty * unit_cost - paid_now owed from public.restocks where shop_id = m.shop_id
            union all
            select trim(supplier), lower(trim(supplier)), -amount from public.supplier_payments where shop_id = m.shop_id) u
         group by k having abs(sum(owed)) > 0.005) y), '[]'::jsonb)
  );
end $$;

-- ------------------------------------------------------------------- moving old phone data
create or replace function public.migrate_products(p_rows jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare m public.members; r jsonb; v_id bigint; v_map jsonb := '[]'::jsonb;
begin
  m := public._owner();
  if (select migrated_at from public.shops where id = m.shop_id) is not null then
    raise exception 'Your old records were already moved.';
  end if;
  for r in select * from jsonb_array_elements(p_rows) loop
    insert into public.products (shop_id, name, category, unit, sell_price, stock_qty, reorder_level, active, created_at)
      values (m.shop_id, r->>'name', r->>'category', r->>'unit', (r->>'sell')::numeric, (r->>'qty')::numeric,
              (r->>'reorder')::numeric, (r->>'active')::boolean, (r->>'created')::bigint)
      returning id into v_id;
    insert into public.product_costs (product_id, shop_id, cost_price) values (v_id, m.shop_id, (r->>'cost')::numeric);
    v_map := v_map || jsonb_build_array(jsonb_build_object('old', (r->>'id')::bigint, 'new', v_id));
  end loop;
  return v_map;
end $$;

create or replace function public.migrate_customers(p_rows jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare m public.members; r jsonb; v_id bigint; v_map jsonb := '[]'::jsonb;
begin
  m := public._owner();
  if (select migrated_at from public.shops where id = m.shop_id) is not null then
    raise exception 'Your old records were already moved.';
  end if;
  for r in select * from jsonb_array_elements(p_rows) loop
    insert into public.customers (shop_id, name, phone) values (m.shop_id, r->>'name', coalesce(r->>'phone', ''))
      returning id into v_id;
    v_map := v_map || jsonb_build_array(jsonb_build_object('old', (r->>'id')::bigint, 'new', v_id));
  end loop;
  return v_map;
end $$;

-- sales: product_id and customer_id must already be the NEW ids. Stock is not touched.
create or replace function public.migrate_sales(p_rows jsonb) returns int
language plpgsql security definer set search_path = public as $$
declare m public.members; r jsonb; it jsonb; v_sale bigint; v_item bigint; n int := 0;
begin
  m := public._owner();
  if (select migrated_at from public.shops where id = m.shop_id) is not null then
    raise exception 'Your old records were already moved.';
  end if;
  for r in select * from jsonb_array_elements(p_rows) loop
    insert into public.sales (shop_id, time, total, method, customer_id, note, voided, created_by, created_by_name)
      values (m.shop_id, (r->>'time')::bigint, (r->>'total')::numeric, r->>'method',
              nullif(r->>'customer_id', '')::bigint, coalesce(r->>'note', ''), (r->>'voided')::boolean, null, 'Imported')
      returning id into v_sale;
    for it in select * from jsonb_array_elements(r->'items') loop
      insert into public.sale_items (sale_id, shop_id, product_id, name, qty, unit_price)
        values (v_sale, m.shop_id, (it->>'product_id')::bigint, it->>'name', (it->>'qty')::numeric, (it->>'unit_price')::numeric)
        returning id into v_item;
      insert into public.sale_costs (sale_item_id, shop_id, unit_cost) values (v_item, m.shop_id, (it->>'unit_cost')::numeric);
    end loop;
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function public.migrate_other(p_data jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members; r jsonb;
begin
  m := public._owner();
  if (select migrated_at from public.shops where id = m.shop_id) is not null then
    raise exception 'Your old records were already moved.';
  end if;
  for r in select * from jsonb_array_elements(coalesce(p_data->'restocks', '[]'::jsonb)) loop
    insert into public.restocks (shop_id, time, product_id, product_name, qty, unit_cost, supplier, paid_now, created_by_name)
      values (m.shop_id, (r->>'time')::bigint, (r->>'product_id')::bigint, r->>'product_name', (r->>'qty')::numeric,
              (r->>'unit_cost')::numeric, coalesce(r->>'supplier', ''), (r->>'paid_now')::numeric, 'Imported');
  end loop;
  for r in select * from jsonb_array_elements(coalesce(p_data->'supplier_payments', '[]'::jsonb)) loop
    insert into public.supplier_payments (shop_id, time, supplier, amount, note)
      values (m.shop_id, (r->>'time')::bigint, r->>'supplier', (r->>'amount')::numeric, coalesce(r->>'note', ''));
  end loop;
  for r in select * from jsonb_array_elements(coalesce(p_data->'adjustments', '[]'::jsonb)) loop
    insert into public.adjustments (shop_id, time, product_id, product_name, qty_change, unit_cost, reason, created_by_name)
      values (m.shop_id, (r->>'time')::bigint, (r->>'product_id')::bigint, r->>'product_name', (r->>'qty_change')::numeric,
              (r->>'unit_cost')::numeric, r->>'reason', 'Imported');
  end loop;
  for r in select * from jsonb_array_elements(coalesce(p_data->'expenses', '[]'::jsonb)) loop
    insert into public.expenses (shop_id, time, category, amount, note)
      values (m.shop_id, (r->>'time')::bigint, r->>'category', (r->>'amount')::numeric, coalesce(r->>'note', ''));
  end loop;
  for r in select * from jsonb_array_elements(coalesce(p_data->'owner_txns', '[]'::jsonb)) loop
    insert into public.owner_txns (shop_id, time, amount, note)
      values (m.shop_id, (r->>'time')::bigint, (r->>'amount')::numeric, coalesce(r->>'note', ''));
  end loop;
  for r in select * from jsonb_array_elements(coalesce(p_data->'customer_payments', '[]'::jsonb)) loop
    insert into public.customer_payments (shop_id, customer_id, time, amount, note)
      values (m.shop_id, (r->>'customer_id')::bigint, (r->>'time')::bigint, (r->>'amount')::numeric, coalesce(r->>'note', ''));
  end loop;
end $$;

create or replace function public.migrate_finish(p_name text, p_symbol text, p_opening numeric) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members;
begin
  m := public._owner();
  update public.shops set name = coalesce(nullif(trim(p_name), ''), name), symbol = coalesce(nullif(trim(p_symbol), ''), symbol),
         opening_money = coalesce(p_opening, 0), migrated_at = public.now_ms()
   where id = m.shop_id;
  perform public._log(m.shop_id, m.display_name, 'Old phone records moved to the cloud', '');
end $$;

-- ------------------------------------------------------------------------------ permissions
revoke all on all tables in schema public from anon, authenticated;
grant usage on schema public to authenticated;
grant select on public.shops, public.members, public.products, public.product_costs, public.customers,
  public.sales, public.sale_items, public.sale_costs, public.restocks, public.supplier_payments,
  public.adjustments, public.expenses, public.owner_txns, public.customer_payments, public.activity_log
  to authenticated;

do $$
declare r record;
begin
  for r in select p.oid::regprocedure as sig, p.proname
             from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and p.prokind = 'f' loop
    execute format('revoke all on function %s from public, anon, authenticated', r.sig);
    if left(r.proname, 1) <> '_' then
      execute format('grant execute on function %s to authenticated', r.sig);
    end if;
  end loop;
end $$;
