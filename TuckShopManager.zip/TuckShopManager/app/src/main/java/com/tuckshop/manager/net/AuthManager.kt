package com.tuckshop.manager.net

import com.tuckshop.manager.data.AuthState
import com.tuckshop.manager.data.MemberInfo
import com.tuckshop.manager.data.ShopRepository
import com.tuckshop.manager.data.ShopInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject

/** Sign-in, sign-up and the list of who is signed in. Owners use an email; employees use shop code + username. */
class AuthManager(private val api: Api, private val repo: ShopRepository) {

    private val _state = MutableStateFlow<AuthState>(AuthState.Loading)
    val state: StateFlow<AuthState> get() = _state

    val usernameRule = "Use 3 to 20 letters or numbers (no spaces), for example: mary or till2."

    fun validUsername(u: String): Boolean = Regex("^[a-z0-9._-]{3,20}$").matches(u.trim().lowercase())

    /** Called once when the app starts. */
    suspend fun start() {
        if (api.session == null) {
            _state.value = AuthState.SignedOut
            return
        }
        loadProfile()
    }

    suspend fun retry() {
        _state.value = AuthState.Loading
        start()
    }

    private suspend fun loadProfile() {
        val s = api.session
        if (s == null) {
            _state.value = AuthState.SignedOut
            return
        }
        try {
            val rows = api.get("members", "select=*&user_id=eq." + s.userId)
            if (rows.length() == 0) {
                repo.detach()
                _state.value = AuthState.NoAccess(s.staffLogin)
                return
            }
            val m: MemberInfo = ShopRepository.parseMember(rows.getJSONObject(0))
            val shopId = rows.getJSONObject(0).getString("shop_id")
            if (!m.active) {
                repo.detach()
                _state.value = AuthState.NoAccess(s.staffLogin)
                return
            }
            val shop: ShopInfo = ShopRepository.fetchShop(api, shopId)
            repo.attach(shop, m.role == com.tuckshop.manager.data.Role.OWNER)
            _state.value = AuthState.In(m, shop)
        } catch (e: ApiException) {
            if (api.session == null) _state.value = AuthState.SignedOut
            else _state.value = AuthState.Failed(e.message ?: "Could not connect.")
        } catch (e: Exception) {
            _state.value = AuthState.Failed("Could not read your shop details (" + (e.message ?: "unknown") + "). Please try again.")
        }
    }

    /** Reload who I am and my shop (after settings or a licence key changed). */
    suspend fun reload() {
        val cur = _state.value
        if (cur is AuthState.In) {
            try {
                val shop = ShopRepository.fetchShop(api, cur.shop.id)
                repo.attach(shop, cur.isOwner)
                _state.value = AuthState.In(cur.member, shop)
            } catch (e: ApiException) {
            }
        }
    }

    // ---------------------------------------------------------------------------------- owner
    suspend fun ownerSignIn(email: String, password: String) {
        _state.value = AuthState.Loading
        try {
            api.signIn(email.trim(), password, false)
        } catch (e: ApiException) {
            _state.value = AuthState.SignedOut
            throw e
        }
        loadProfile()
    }

    /** Creates the owner's login and the shop in one go. */
    suspend fun ownerSignUp(email: String, password: String, shopName: String, yourName: String) {
        _state.value = AuthState.Loading
        try {
            val r = api.signUp(email.trim(), password, false)
            val session = r.session ?: throw ApiException(
                "Your account was made, but Supabase wants the email confirmed first. In Supabase turn OFF " +
                    "Authentication > Sign In / Providers > Email > Confirm email, then sign in."
            )
            api.adopt(session)
            api.rpc("create_shop", JSONObject().put("p_name", shopName.trim()).put("p_display_name", yourName.trim()))
        } catch (e: ApiException) {
            _state.value = if (api.session == null) AuthState.SignedOut else AuthState.NoAccess(false)
            throw e
        }
        loadProfile()
    }

    /** For an owner whose login exists but whose shop was not created yet. */
    suspend fun createShopNow(shopName: String, yourName: String) {
        api.rpc("create_shop", JSONObject().put("p_name", shopName.trim()).put("p_display_name", yourName.trim()))
        loadProfile()
    }

    // ---------------------------------------------------------------------------------- employee
    suspend fun staffSignIn(shopCode: String, username: String, password: String) {
        _state.value = AuthState.Loading
        try {
            api.signIn(Cloud.staffEmail(shopCode, username), password, true)
        } catch (e: ApiException) {
            _state.value = AuthState.SignedOut
            throw e
        }
        loadProfile()
    }

    /** Owner creates an employee login. Returns nothing; throws a readable error on failure. */
    suspend fun addEmployee(username: String, displayName: String, password: String) {
        val cur = _state.value as? AuthState.In ?: throw ApiException("Please sign in again.", 401)
        val u = username.trim().lowercase()
        if (!validUsername(u)) throw ApiException(usernameRule)
        if (password.length < 6) throw ApiException("The password must have at least 6 characters.")
        val email = Cloud.staffEmail(cur.shop.code, u)
        val made = try {
            api.signUp(email, password, true)
        } catch (e: ApiException) {
            if (e.message?.contains("already") == true) throw ApiException("The username \"$u\" is already used. Pick another one.")
            throw e
        }
        try {
            api.rpc(
                "add_member",
                JSONObject().put("p_user", made.userId).put("p_email", email).put("p_username", u)
                    .put("p_display_name", displayName.trim().ifBlank { u })
            )
        } catch (e: ApiException) {
            throw ApiException(e.message + " (The username \"$u\" may now be used up. Please try a different one.)")
        }
    }

    // ---------------------------------------------------------------------------------- both
    suspend fun changePassword(newPassword: String) {
        if (newPassword.length < 6) throw ApiException("The password must have at least 6 characters.")
        api.changePassword(newPassword)
    }

    fun signOut() {
        api.signOutLocal()
        repo.detach()
        _state.value = AuthState.SignedOut
    }

    /** Used when the server says our login is no longer valid. */
    fun sessionExpired() {
        if (_state.value !is AuthState.SignedOut) signOut()
    }
}
