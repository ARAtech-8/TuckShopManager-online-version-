package com.tuckshop.manager.io

import android.util.Xml
import com.tuckshop.manager.data.ImportRow
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

data class ImportPreview(val rows: List<ImportRow>, val skipped: Int, val error: String?)

/** Reads product sheets from .xlsx or .csv files without any extra libraries. */
object Importer {

    const val TEMPLATE_CSV =
        "Product Name,Category,Unit,Cost Price,Selling Price,Quantity In Stock,Reorder Level\n" +
            "Bread (white loaf),Bakery,each,1.00,1.50,20,5\n" +
            "Coke 500ml,Drinks,each,0.60,1.00,48,12\n" +
            "Sugar 2kg,Groceries,each,2.40,3.00,10,3\n"

    fun readTable(bytes: ByteArray): List<List<String>> {
        val isZip = bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        return if (isZip) readXlsx(bytes) else readCsv(String(bytes, Charsets.UTF_8))
    }

    // ------------------------------------------------------------------ CSV
    fun readCsv(raw: String): List<List<String>> {
        val text = raw.removePrefix("﻿")
        val firstLine = text.lineSequence().firstOrNull() ?: ""
        val delim = listOf(',', ';', '\t').maxByOrNull { d -> firstLine.count { it == d } } ?: ','
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val field = StringBuilder()
        var inQuotes = false
        var i = 0
        val n = text.length
        while (i < n) {
            val ch = text[i]
            if (inQuotes) {
                if (ch == '"') {
                    if (i + 1 < n && text[i + 1] == '"') {
                        field.append('"')
                        i++
                    } else {
                        inQuotes = false
                    }
                } else {
                    field.append(ch)
                }
            } else if (ch == '"') {
                inQuotes = true
            } else if (ch == delim) {
                row.add(field.toString())
                field.setLength(0)
            } else if (ch == '\n') {
                row.add(field.toString())
                field.setLength(0)
                rows.add(row)
                row = ArrayList()
            } else if (ch != '\r') {
                field.append(ch)
            }
            i++
        }
        if (field.isNotEmpty() || row.isNotEmpty()) {
            row.add(field.toString())
            rows.add(row)
        }
        return rows
    }

    // ------------------------------------------------------------------ XLSX
    private fun colIndex(ref: String?): Int {
        if (ref == null) return -1
        var n = 0
        var any = false
        for (c in ref) {
            if (c in 'A'..'Z') {
                n = n * 26 + (c - 'A' + 1)
                any = true
            } else if (c in 'a'..'z') {
                n = n * 26 + (c - 'a' + 1)
                any = true
            } else break
        }
        return if (any) n - 1 else -1
    }

    fun readXlsx(bytes: ByteArray): List<List<String>> {
        val parts = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val name = e.name
                if (name == "xl/sharedStrings.xml" || (name.startsWith("xl/worksheets/sheet") && name.endsWith(".xml"))) {
                    parts[name] = zis.readBytes()
                }
                e = zis.nextEntry
            }
        }
        val sheetName = if (parts.containsKey("xl/worksheets/sheet1.xml")) "xl/worksheets/sheet1.xml"
        else parts.keys.filter { it.startsWith("xl/worksheets/") }.sorted().firstOrNull()
        val sheet = sheetName?.let { parts[it] } ?: return emptyList()
        val shared = parts["xl/sharedStrings.xml"]?.let { parseShared(it) } ?: emptyList()
        return parseSheet(sheet, shared)
    }

    private fun parseShared(xml: ByteArray): List<String> {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), "UTF-8")
        val out = ArrayList<String>()
        var sb: StringBuilder? = null
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    if (p.name == "si") sb = StringBuilder()
                    else if (p.name == "t") inT = true
                }
                XmlPullParser.TEXT -> if (inT) sb?.append(p.text)
                XmlPullParser.END_TAG -> {
                    if (p.name == "t") inT = false
                    else if (p.name == "si") {
                        out.add(sb?.toString() ?: "")
                        sb = null
                    }
                }
            }
            ev = p.next()
        }
        return out
    }

    private fun parseSheet(xml: ByteArray, shared: List<String>): List<List<String>> {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), "UTF-8")
        val rows = ArrayList<List<String>>()
        var current = ArrayList<String>()
        var type: String? = null
        var col = -1
        val text = StringBuilder()
        var inV = false
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> current = ArrayList()
                    "c" -> {
                        type = p.getAttributeValue(null, "t")
                        col = colIndex(p.getAttributeValue(null, "r"))
                        text.setLength(0)
                    }
                    "v" -> inV = true
                    "t" -> inT = true
                }
                XmlPullParser.TEXT -> if (inV || inT) text.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "c" -> {
                        val raw = text.toString()
                        val value = if (type == "s") {
                            val idx = raw.trim().toIntOrNull()
                            if (idx != null && idx >= 0 && idx < shared.size) shared[idx] else ""
                        } else raw
                        val target = if (col >= 0) col else current.size
                        while (current.size < target) current.add("")
                        if (current.size == target) current.add(value)
                        else current[target] = value
                    }
                    "row" -> rows.add(current)
                }
            }
            ev = p.next()
        }
        return rows
    }

    // ------------------------------------------------------------------ mapping to products
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private val nameKeys = setOf("name", "product", "productname", "item", "itemname", "description", "article")
    private val categoryKeys = setOf("category", "type", "group", "department")
    private val unitKeys = setOf("unit", "uom", "measure")
    private val costKeys = setOf("cost", "costprice", "buyingprice", "buyprice", "purchaseprice", "unitcost", "cp", "buying")
    private val sellKeys = setOf("price", "sellingprice", "sellprice", "saleprice", "retailprice", "sp", "unitprice", "selling")
    private val qtyKeys = setOf(
        "qty", "quantity", "stock", "instock", "onhand", "openingstock", "stockonhand", "currentstock",
        "quantityinstock", "stockqty"
    )
    private val reorderKeys = setOf("reorder", "reorderlevel", "minimum", "min", "minstock", "lowstock", "alertlevel")

    private fun num(s: String?): Double? {
        if (s == null) return null
        val t = s.trim().replace(",", "").filter { it.isDigit() || it == '.' || it == '-' }
        return t.toDoubleOrNull()
    }

    fun toProducts(table: List<List<String>>): ImportPreview {
        var headerIdx = -1
        for (i in 0 until minOf(table.size, 8)) {
            if (table[i].any { norm(it) in nameKeys }) {
                headerIdx = i
                break
            }
        }
        if (headerIdx < 0) {
            return ImportPreview(
                emptyList(), 0,
                "I could not find a 'Product Name' column in the first rows of this file. " +
                    "Use 'Get template' to see the layout, fill it in, and try again."
            )
        }
        val header = table[headerIdx].map { norm(it) }
        fun find(keys: Set<String>): Int = header.indexOfFirst { it in keys }
        val iName = find(nameKeys)
        val iCat = find(categoryKeys)
        val iUnit = find(unitKeys)
        val iCost = find(costKeys)
        val iSell = find(sellKeys)
        val iQty = find(qtyKeys)
        val iRe = find(reorderKeys)

        fun cell(r: List<String>, i: Int): String? = if (i >= 0 && i < r.size) r[i] else null

        val rows = ArrayList<ImportRow>()
        var skipped = 0
        for (r in table.drop(headerIdx + 1)) {
            if (r.all { it.isBlank() }) continue
            val name = cell(r, iName)?.trim().orEmpty()
            val sell = num(cell(r, iSell))
            val cost = num(cell(r, iCost))
            if (name.isEmpty() || (sell != null && sell < 0) || (cost != null && cost < 0)) {
                skipped++
                continue
            }
            rows.add(
                ImportRow(
                    name = name,
                    category = cell(r, iCat)?.trim().orEmpty(),
                    unit = cell(r, iUnit)?.trim().orEmpty(),
                    cost = cost,
                    sell = sell,
                    qty = num(cell(r, iQty)),
                    reorder = num(cell(r, iRe))
                )
            )
        }
        return ImportPreview(rows, skipped, null)
    }
}
