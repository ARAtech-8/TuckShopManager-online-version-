@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.tuckshop.manager.ShopViewModel
import com.tuckshop.manager.data.ActivityEntry
import com.tuckshop.manager.data.AuthState
import com.tuckshop.manager.data.MemberInfo
import com.tuckshop.manager.data.Method
import com.tuckshop.manager.data.Product
import com.tuckshop.manager.data.Role
import com.tuckshop.manager.domain.Fmt
import com.tuckshop.manager.domain.Period
import com.tuckshop.manager.domain.range
import com.tuckshop.manager.io.Share
import com.tuckshop.manager.legacy.Migrator
import com.tuckshop.manager.net.ApiException
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ============================================================================ small shared pieces
@Composable
fun RefreshAction(vm: ShopViewModel) {
    TextButton(onClick = { vm.repo.refresh(); vm.say("Updating...") }) {
        Text("Refresh", color = Color.White)
    }
}

@Composable
fun OfflineBar(vm: ShopViewModel) {
    val online by vm.repo.online.collectAsState()
    if (!online) {
        Text(
            "No internet. Showing the last information. Sales cannot be saved until you are back online.",
            color = Color.White, fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().background(Ui.Bad).padding(8.dp)
        )
    }
}

// ============================================================================ employee home: "My day"
@Composable
fun EmployeeHome(vm: ShopViewModel, nav: NavHostController) {
    val settings by vm.settings.collectAsState()
    val products by vm.products.collectAsState()
    val flow = remember { vm.repo.recentSales(200) }
    val sales by flow.collectAsState(initial = emptyList())
    val start = remember(sales) { Period.TODAY.range(vm.api.now()).start }
    val mine = sales.filter { it.time >= start && !it.voided }
    val total = mine.sumOf { it.total }
    val low = products.filter { it.stockQty <= it.reorderLevel }

    ScreenFrame(settings.shopName, actions = { RefreshAction(vm) }) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Hello " + vm.myName + "  |  " + SimpleDateFormat("EEEE, d MMMM", Locale.US).format(Date(vm.api.now())), color = Ui.Muted)
            WhiteCard {
                Text("You sold today", color = Ui.Muted)
                Text(money(total), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text(mine.size.toString() + (if (mine.size == 1) " sale" else " sales"), color = Ui.Muted, fontSize = 12.sp)
                val cash = mine.filter { it.method == Method.CASH }.sumOf { it.total }
                val mobile = mine.filter { it.method == Method.MOBILE }.sumOf { it.total }
                val credit = mine.filter { it.method == Method.CREDIT }.sumOf { it.total }
                Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Cash to hand in: " + money(cash), fontWeight = FontWeight.Bold)
                    Text("Mobile money: " + money(mobile))
                    if (credit > 0.005) Text("On credit: " + money(credit))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { nav.navigate("sell") }, modifier = Modifier.weight(1f)) { Text("New sale") }
                FilledTonalButton(onClick = { nav.navigate("sales") }, modifier = Modifier.weight(1f)) { Text("My sales") }
            }
            if (low.isNotEmpty()) {
                WhiteCard {
                    Text("Tell your employer: running low", fontWeight = FontWeight.Bold)
                    low.take(8).forEach {
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(it.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (it.stockQty <= 0) "out" else Fmt.qty(it.stockQty) + " left",
                                color = if (it.stockQty <= 0) Ui.Bad else Ui.Warn, fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    if (low.size > 8) Text("and " + (low.size - 8) + " more (see Stock)", fontSize = 12.sp, color = Ui.Muted)
                }
            }
            if (mine.isNotEmpty()) {
                WhiteCard {
                    Text("Your latest sales today", fontWeight = FontWeight.Bold)
                    mine.take(6).forEach { s ->
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(Fmt.dateTime(s.time) + "  " + Method.label(s.method))
                            Text(money(s.total), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================ employee stock: look and report
@Composable
fun EmployeeStockScreen(vm: ShopViewModel) {
    val products by vm.products.collectAsState()
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    var report by remember { mutableStateOf<Product?>(null) }
    val shown = products.filter {
        (query.isBlank() || it.name.contains(query, true) || it.category.contains(query, true)) &&
            when (filter) {
                "Running low" -> it.stockQty > 0 && it.stockQty <= it.reorderLevel
                "Out of stock" -> it.stockQty <= 0
                else -> true
            }
    }
    ScreenFrame("Stock", actions = { RefreshAction(vm) }) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Tap an item if some of it is damaged, expired or missing.", color = Ui.Muted, fontSize = 13.sp)
            OutlinedTextField(
                value = query, onValueChange = { query = it }, label = { Text("Search") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            ChipChoice(listOf("All", "Running low", "Out of stock"), filter) { filter = it }
        }
        if (products.isEmpty()) EmptyHint("No products yet. Your employer adds them.")
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(shown, key = { it.id }) { p ->
                Card(
                    Modifier.fillMaxWidth().clickable { report = p },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(p.category + "  |  sells " + money(p.sellPrice), fontSize = 12.sp, color = Ui.Muted)
                        }
                        Text(
                            Fmt.qty(p.stockQty), fontSize = 20.sp, fontWeight = FontWeight.Bold,
                            color = if (p.stockQty <= 0) Ui.Bad else if (p.stockQty <= p.reorderLevel) Ui.Warn else Color.Unspecified
                        )
                    }
                }
            }
        }
    }
    report?.let { p -> EmployeeRemoveDialog(vm, p) { report = null } }
}

@Composable
private fun EmployeeRemoveDialog(vm: ShopViewModel, p: Product, onDismiss: () -> Unit) {
    val reasons = listOf("Damaged", "Expired", "Missing or stolen", "Used at home")
    var reason by remember { mutableStateOf(reasons[0]) }
    var qty by remember { mutableStateOf("") }
    val n = qty.toNum()
    FormDialog(
        "Report: " + p.name, "Save", onDismiss,
        onConfirm = {
            vm.go("Reported. Your employer can see this.") { vm.repo.adjust(p.id, -n!!, reason) }
            onDismiss()
        },
        confirmEnabled = n != null && n > 0
    ) {
        Text("Now in stock: " + Fmt.qty(p.stockQty), color = Ui.Muted)
        ChipChoice(reasons, reason) { reason = it }
        NumInput(qty, { qty = it }, "How many " + p.unit + " to remove?")
        Text("Your name is saved with this report.", fontSize = 12.sp, color = Ui.Muted)
    }
}

// ============================================================================ staff (owner)
@Composable
fun StaffScreen(vm: ShopViewModel, st: AuthState.In, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val version by vm.repo.version.collectAsState()
    var reload by remember { mutableStateOf(0) }
    val members by produceState<List<MemberInfo>?>(null, version, reload) {
        value = try { vm.repo.members() } catch (e: Exception) { value }
    }
    var adding by remember { mutableStateOf(false) }
    var created by remember { mutableStateOf<Triple<String, String, String>?>(null) }

    ScreenFrame("Your employees", onBack = onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            WhiteCard {
                Text("Your Shop Code", fontSize = 12.sp, color = Ui.Muted)
                Text(st.shop.code, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Employees sign in with this code, their username and their password. " +
                        "They can sell and cancel their own sales, but they cannot see costs, profit, expenses or reports.",
                    fontSize = 12.sp, color = Ui.Muted
                )
            }
            Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add an employee") }

            val list = members
            if (list == null) EmptyHint("Loading...")
            else list.filter { it.role == Role.EMPLOYEE }.let { emps ->
                if (emps.isEmpty()) EmptyHint("No employees yet.")
                emps.forEach { m ->
                    WhiteCard {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(m.displayName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("Username: " + m.username, fontSize = 12.sp, color = Ui.Muted)
                                Text(
                                    if (m.active) "Active" else "Switched off",
                                    fontSize = 12.sp, color = if (m.active) Ui.Good else Ui.Bad, fontWeight = FontWeight.Bold
                                )
                            }
                            OutlinedButton(onClick = {
                                vm.go(if (m.active) "Switched off" else "Switched on") {
                                    vm.repo.setMemberActive(m.userId, !m.active)
                                    reload++
                                }
                            }) { Text(if (m.active) "Switch off" else "Switch on") }
                        }
                    }
                }
            }
            Text(
                "If an employee forgets their password: switch their login off and add them again with a new username. " +
                    "Employees can change their own password under More > My account.",
                fontSize = 12.sp, color = Ui.Muted
            )
        }
    }

    if (adding) AddEmployeeDialog(vm, st, onDismiss = { adding = false }) { name, user, pass ->
        adding = false
        created = Triple(name, user, pass)
        reload++
    }
    created?.let { (name, user, pass) ->
        val text = "Tuck Shop Manager login for $name\nShop code: ${st.shop.code}\nUsername: $user\nPassword: $pass"
        AlertDialog(
            onDismissRequest = { created = null },
            title = { Text("Employee added", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Give these details to $name:")
                    Text("Shop code:  " + st.shop.code, fontWeight = FontWeight.Bold)
                    Text("Username:  $user", fontWeight = FontWeight.Bold)
                    Text("Password:  $pass", fontWeight = FontWeight.Bold)
                    Text("The password is not shown again.", fontSize = 12.sp, color = Ui.Muted)
                }
            },
            confirmButton = { TextButton(onClick = { created = null }) { Text("Done") } },
            dismissButton = { TextButton(onClick = { Share.shareText(ctx, text) }) { Text("Share") } }
        )
    }
}

@Composable
private fun AddEmployeeDialog(vm: ShopViewModel, st: AuthState.In, onDismiss: () -> Unit, onDone: (String, String, String) -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf(randomPassword()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val userOk = vm.auth.validUsername(user)
    FormDialog(
        "Add an employee", if (busy) "Please wait..." else "Add", onDismiss,
        onConfirm = {
            busy = true; error = null
            scope.launch {
                try {
                    vm.auth.addEmployee(user, name, pass)
                    onDone(name.trim().ifBlank { user.trim().lowercase() }, user.trim().lowercase(), pass)
                } catch (e: ApiException) {
                    error = e.message
                } catch (e: Exception) {
                    error = "Something went wrong: " + (e.message ?: "")
                } finally {
                    busy = false
                }
            }
        },
        confirmEnabled = !busy && name.isNotBlank() && userOk && pass.length >= 6
    ) {
        TextInput(name, { name = it }, "Employee's name")
        OutlinedTextField(
            user, { user = it.lowercase().filter { c -> !c.isWhitespace() } }, label = { Text("Username") }, singleLine = true,
            supportingText = { Text(vm.auth.usernameRule) }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            pass, { pass = it }, label = { Text("Password (6 or more)") }, singleLine = true,
            supportingText = { Text("Shown to you now so you can tell the employee.") }, modifier = Modifier.fillMaxWidth()
        )
        error?.let { Text(it, color = Ui.Bad) }
    }
}

private fun randomPassword(): String {
    val chars = "abcdefghjkmnpqrstuvwxyz23456789"
    val r = java.security.SecureRandom()
    return (1..8).map { chars[r.nextInt(chars.length)] }.joinToString("")
}

// ============================================================================ activity log (owner)
@Composable
fun ActivityScreen(vm: ShopViewModel, onBack: () -> Unit) {
    val version by vm.repo.version.collectAsState()
    val log by produceState<List<ActivityEntry>?>(null, version) {
        value = try { vm.repo.activity() } catch (e: Exception) { value }
    }
    ScreenFrame("Who did what", onBack = onBack, actions = { RefreshAction(vm) }) {
        val list = log
        if (list == null) EmptyHint("Loading...")
        else if (list.isEmpty()) EmptyHint("Nothing recorded yet.")
        else LazyColumn(
            Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(list, key = { it.id }) { e ->
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(e.action, fontWeight = FontWeight.Bold)
                        if (e.detail.isNotBlank()) Text(e.detail, fontSize = 13.sp)
                        Text(e.userName + "  |  " + Fmt.dateTime(e.time), fontSize = 12.sp, color = Ui.Muted)
                    }
                }
            }
        }
    }
}

// ============================================================================ account (everyone)
@Composable
fun AccountScreen(vm: ShopViewModel, st: AuthState.In, onBack: () -> Unit) {
    var changing by remember { mutableStateOf(false) }
    var pw1 by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    ScreenFrame("My account", onBack = onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            WhiteCard {
                Text(st.member.displayName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(if (st.isOwner) "Owner" else "Employee  |  username " + st.member.username, color = Ui.Muted)
                Text("Shop: " + st.shop.name + "   (code " + st.shop.code + ")", color = Ui.Muted, fontSize = 13.sp)
            }
            WhiteCard {
                SectionTitle("Change my password")
                PasswordField(pw1, { pw1 = it }, "New password (6 or more)")
                PasswordField(pw2, { pw2 = it }, "Type it again", Modifier.fillMaxWidth().padding(top = 8.dp))
                Button(
                    onClick = {
                        busy = true
                        scope.launch {
                            try {
                                vm.auth.changePassword(pw1)
                                vm.say("Password changed")
                                pw1 = ""; pw2 = ""
                            } catch (e: ApiException) {
                                vm.say(e.message ?: "Could not change the password.")
                            } finally {
                                busy = false
                            }
                        }
                    },
                    enabled = !busy && pw1.length >= 6 && pw1 == pw2,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) { Text("Change password") }
                if (pw2.isNotEmpty() && pw1 != pw2) Text("The two passwords are different.", color = Ui.Bad, fontSize = 12.sp)
            }
            OutlinedButton(onClick = { changing = true }, modifier = Modifier.fillMaxWidth()) { Text("Sign out") }
        }
    }
    if (changing) {
        AlertDialog(
            onDismissRequest = { changing = false },
            title = { Text("Sign out?") },
            text = { Text("You will need your details to sign in again.") },
            confirmButton = { Button(onClick = { changing = false; vm.signOut() }) { Text("Sign out") } },
            dismissButton = { TextButton(onClick = { changing = false }) { Text("Stay") } }
        )
    }
}

// ============================================================================ move old records (owner)
@Composable
fun MigrateCard(vm: ShopViewModel, st: AuthState.In) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val hasOld = remember { Migrator.hasOldRecords(ctx) }
    var confirm by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<String?>(null) }
    var summary by remember { mutableStateOf<String?>(null) }
    if (!hasOld || st.shop.migratedAt != null) return

    WhiteCard {
        SectionTitle(
            "Move my old records online",
            "The records you kept on this phone before can be copied into your online shop, once."
        )
        Button(onClick = {
            scope.launch {
                try {
                    val c = Migrator.count(ctx)
                    summary = c.products.toString() + " products, " + c.customers + " customers, " + c.sales + " sales and " +
                        c.other + " other records"
                    confirm = true
                } catch (e: Exception) {
                    vm.say("Could not read the old records on this phone.")
                }
            }
        }, enabled = progress == null, modifier = Modifier.fillMaxWidth()) { Text(progress ?: "Move my old records") }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Move old records?") },
            text = {
                Text(
                    "This copies $summary into your online shop. Do this only once, and only while your online shop is still empty " +
                        "(no products or sales added yet). Keep the app open and connected until it says Done."
                )
            },
            confirmButton = {
                Button(onClick = {
                    confirm = false
                    progress = "Starting..."
                    scope.launch {
                        try {
                            Migrator.run(ctx, vm.api) { progress = it }
                            vm.auth.reload()
                            vm.repo.refresh()
                            vm.say("Done. Your old records are now online.")
                        } catch (e: ApiException) {
                            vm.say(e.message ?: "The move stopped.")
                        } catch (e: Exception) {
                            vm.say("The move stopped: " + (e.message ?: "unknown error"))
                        } finally {
                            progress = null
                        }
                    }
                }) { Text("Yes, move them") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Not now") } }
        )
    }
}
