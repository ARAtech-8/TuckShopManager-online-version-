package com.tuckshop.manager

import android.app.Application
import com.tuckshop.manager.data.ShopRepository
import com.tuckshop.manager.net.Api
import com.tuckshop.manager.net.AuthManager

class TuckShopApp : Application() {
    lateinit var api: Api
        private set
    lateinit var repo: ShopRepository
        private set
    lateinit var auth: AuthManager
        private set

    override fun onCreate() {
        super.onCreate()
        api = Api(this)
        repo = ShopRepository(api)
        auth = AuthManager(api, repo)
    }
}
