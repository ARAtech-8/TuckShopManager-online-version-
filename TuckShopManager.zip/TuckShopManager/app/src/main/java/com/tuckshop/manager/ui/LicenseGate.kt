@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuckshop.manager.ShopViewModel
import com.tuckshop.manager.data.AuthState
import com.tuckshop.manager.domain.License
import com.tuckshop.manager.net.ApiException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Milliseconds left of the free trial, or null when the shop is fully unlocked. */
val LocalTrialMsLeft = compositionLocalOf<Long?> { null }

fun trialText(ms: Long): String {
    val hours = ms / 3_600_000L
    return if (hours >= 1) "about $hours hour" + (if (hours == 1L) "" else "s") + " left" else "less than 1 hour left"
}

/**
 * The shop gets a 1-day free trial from the day it was created (server time). After that the owner enters a key
 * that belongs to the shop's code. Employees just see a message to tell their employer.
 */
@Composable
fun LicenseGate(vm: ShopViewModel, st: AuthState.In, content: @Composable () -> Unit) {
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000)
            tick++
        }
    }
    val shop = st.shop
    val activated = shop.licenseKey != null && License.isValid(shop.code, shop.licenseKey)
    val left = remember(tick, shop.createdAt) { shop.createdAt + License.TRIAL_MS - vm.api.now() }
    if (!activated && left <= 0L) {
        LockScreen(vm, st)
    } else {
        CompositionLocalProvider(LocalTrialMsLeft provides (if (activated) null else left)) {
            content()
        }
    }
}

@Composable
fun LockScreen(vm: ShopViewModel, st: AuthState.In) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var failure by remember { mutableStateOf<String?>(null) }
    val code = st.shop.code

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
    ) {
        Text("Tuck Shop Manager", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ui.Good)
        Text("The free trial has ended.", fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)

        if (!st.isOwner) {
            Text(
                "Please tell your employer: the shop needs a licence key before it can be used again.",
                textAlign = TextAlign.Center
            )
            OutlinedButton(onClick = { vm.signOut() }, modifier = Modifier.fillMaxWidth()) { Text("Sign out") }
            return@Column
        }

        Text(
            "WhatsApp " + License.WHATSAPP_DISPLAY + " to get key",
            fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
        )
        Button(
            onClick = {
                val msg = "Hello, I would like a key for Tuck Shop Manager. My Shop Code is $code"
                val uri = Uri.parse("https://wa.me/" + License.WHATSAPP + "?text=" + Uri.encode(msg))
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (e: Exception) {
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Open WhatsApp") }

        WhiteCard {
            Text("Your Shop Code (send this with your request)", fontSize = 12.sp, color = Ui.Muted)
            Text(code, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            OutlinedButton(
                onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Shop Code", code))
                },
                modifier = Modifier.padding(top = 6.dp)
            ) { Text("Copy Shop Code") }
        }

        OutlinedTextField(
            value = key,
            onValueChange = { key = it; wrong = false; failure = null },
            label = { Text("Type or paste your key") },
            singleLine = true,
            isError = wrong,
            supportingText = if (wrong) ({ Text("That key is not correct for this shop.") }) else null,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                if (!License.isValid(code, key)) {
                    wrong = true
                } else {
                    busy = true
                    scope.launch {
                        try {
                            vm.repo.saveLicenseKey(key.trim())
                            vm.auth.reload()
                        } catch (e: ApiException) {
                            failure = e.message
                        } finally {
                            busy = false
                        }
                    }
                }
            },
            enabled = key.isNotBlank() && !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "Unlocking..." else "Unlock") }
        failure?.let { Text(it, color = Ui.Bad, textAlign = TextAlign.Center) }

        Text(
            "Your records are safe online. They will all be here when you unlock.",
            fontSize = 12.sp, color = Ui.Muted, textAlign = TextAlign.Center
        )
        OutlinedButton(onClick = { vm.signOut() }, modifier = Modifier.fillMaxWidth()) { Text("Sign out") }
    }
}
