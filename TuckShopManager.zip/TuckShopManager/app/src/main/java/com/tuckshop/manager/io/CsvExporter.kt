package com.tuckshop.manager.io

import com.tuckshop.manager.domain.Doc
import com.tuckshop.manager.domain.ShopSettings

/** Spreadsheet-friendly export. Excel opens .csv files directly. */
object CsvExporter {
    private val numeric = Regex("^-?[0-9,]+(\\.[0-9]+)?$")

    private fun field(s: String): String {
        val v = if (numeric.matches(s)) s.replace(",", "") else s
        return if (v.contains(',') || v.contains('"') || v.contains('\n')) "\"" + v.replace("\"", "\"\"") + "\"" else v
    }

    fun build(shop: ShopSettings, periodLabel: String, rangeText: String, docs: List<Doc>): ByteArray {
        val sb = StringBuilder("﻿")
        for (d in docs) {
            sb.append(field(shop.shopName)).append('\n')
            sb.append(field(d.title)).append(',').append(field("$periodLabel ($rangeText)")).append('\n')
            for (r in d.rows) sb.append(r.cells.joinToString(",") { field(it) }).append('\n')
            sb.append('\n')
        }
        return sb.toString().toByteArray(Charsets.UTF_8)
    }
}
