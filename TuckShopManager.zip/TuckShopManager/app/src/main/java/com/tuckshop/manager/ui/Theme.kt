package com.tuckshop.manager.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Ui {
    val Good = Color(0xFF1B7F4B)
    val Bad = Color(0xFFB3261E)
    val Warn = Color(0xFF9A6700)
    val Soft = Color(0xFFE8F3EC)
    val Muted = Color(0xFF5F6B63)
}

private val Scheme = lightColorScheme(
    primary = Color(0xFF1B7F4B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD9EDE0),
    onPrimaryContainer = Color(0xFF00391F),
    secondary = Color(0xFF8A5A00),
    secondaryContainer = Color(0xFFFFE7B3),
    onSecondaryContainer = Color(0xFF2B1A00),
    background = Color(0xFFFAFAF7),
    surface = Color.White,
    surfaceVariant = Color(0xFFEFF3EE),
    error = Color(0xFFB3261E)
)

@Composable
fun TuckShopTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
