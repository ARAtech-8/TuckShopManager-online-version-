package com.tuckshop.manager.data

import com.tuckshop.manager.domain.Engine
import com.tuckshop.manager.domain.Period
import com.tuckshop.manager.domain.Position
import com.tuckshop.manager.domain.RawData
import com.tuckshop.manager.domain.ReportBundle
import com.tuckshop.manager.domain.ShopSettings
import com.tuckshop.manager.domain.TimeRange
import com.tuckshop.manager.domain.previousRange
import com.tuckshop.manager.domain.range
import com.tuckshop.manager.net.Api
import com.tuckshop.manager.net.ApiException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

private fun JSONObject.str(k: String, d: String = ""): String = if (isNull(k)) d else optString(k, d)
private fun JSONObject.dbl(k: String, d: Double = 0.0): Double = if (isNull(k)) d else optDouble(k, d)
private fun JSONObject.lng(k: String, d: Long = 0L): Long = if (isNull(k)) d else optLong(k, d)
private fun JSONArray.objs(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

/**
 * All shop data, kept in Supabase. Screens read lists as Flows that reload after every change and once a minute
 * (so a sale made on an employee's phone shows up on the owner's phone). Every write is a database function that
 * checks, on the server, what the signed-in person may do.
 */
class ShopRepository(private val api: Api) {

    private val shopState = MutableStateFlow<ShopInfo?>(null)
    val shop: StateFlow<ShopInfo?> get() = shopState

    private val settingsState = MutableStateFlow(ShopSettings())
    val settings: StateFlow<ShopSettings> get() = settingsState

    @Volatile var isOwner: Boolean = false
        private set

    /** Goes up by one after every change, so screens know to reload. */
    val version = MutableStateFlow(0)
    fun refresh() {
        version.value = version.value + 1
    }

    /** False while the phone cannot reach the internet. */
    val online = MutableStateFlow(true)

    /** Called after sign-in, and again when the shop details change. */
    fun attach(s: ShopInfo, owner: Boolean) {
        shopState.value = s
        isOwner = owner
        settingsState.value = ShopSettings(s.name, s.symbol, s.openingMoney)
        refresh()
    }

    fun detach() {
        shopState.value = null
        isOwner = false
        productCache = emptyList()
        customerCache = emptyList()
        refresh()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun <T> live(tickMs: Long = 60_000L, load: suspend () -> T): Flow<T> =
        version.flatMapLatest {
            flow {
                while (true) {
                    if (shopState.value != null) {
                        try {
                            emit(load())
                            online.value = true
                        } catch (e: ApiException) {
                            if (e.offline) online.value = false
                        } catch (e: Exception) {
                        }
                    }
                    delay(tickMs)
                }
            }
        }

    private suspend fun <T> io(block: suspend () -> T): T = withContext(Dispatchers.IO) { block() }

    /** Runs a change, then makes every screen reload. */
    private suspend fun <T> change(block: suspend () -> T): T {
        try {
            return block()
        } finally {
            refresh()
        }
    }

    // ---------------------------------------------------------------- reading lists
    @Volatile private var productCache: List<Product> = emptyList()
    @Volatile private var customerCache: List<Customer> = emptyList()

    private fun parseProduct(j: JSONObject): Product {
        var cost = 0.0
        val pc = j.opt("product_costs")
        if (pc is JSONObject) cost = pc.dbl("cost_price")
        else if (pc is JSONArray && pc.length() > 0) cost = pc.getJSONObject(0).dbl("cost_price")
        return Product(
            id = j.lng("id"), name = j.str("name"), category = j.str("category", "General"), unit = j.str("unit", "each"),
            costPrice = cost, sellPrice = j.dbl("sell_price"), stockQty = j.dbl("stock_qty"),
            reorderLevel = j.dbl("reorder_level", 5.0), active = j.optBoolean("active", true), createdAt = j.lng("created_at")
        )
    }

    private suspend fun loadProducts(): List<Product> {
        val q = if (isOwner) "select=*,product_costs(cost_price)&active=eq.true&order=name"
        else "select=id,name,category,unit,sell_price,stock_qty,reorder_level,active,created_at&active=eq.true&order=name"
        val list = api.get("products", q).objs().map { parseProduct(it) }
        productCache = list
        return list
    }

    private suspend fun loadCustomers(): List<Customer> {
        val list = api.get("customers", "select=id,name,phone&order=name").objs()
            .map { Customer(it.lng("id"), it.str("name"), it.str("phone")) }
        customerCache = list
        return list
    }

    val products: Flow<List<Product>> = live { loadProducts() }
    val customers: Flow<List<Customer>> = live { loadCustomers() }

    val expenses: Flow<List<Expense>> = live {
        api.get("expenses", "select=*&order=time.desc&limit=500").objs()
            .map { Expense(it.lng("id"), it.lng("time"), it.str("category"), it.dbl("amount"), it.str("note")) }
    }

    val ownerTxns: Flow<List<OwnerTxn>> = live {
        api.get("owner_txns", "select=*&order=time.desc&limit=500").objs()
            .map { OwnerTxn(it.lng("id"), it.lng("time"), it.dbl("amount"), it.str("note")) }
    }

    private fun parseSale(j: JSONObject) = Sale(
        id = j.lng("id"), time = j.lng("time"), total = j.dbl("total"), method = j.str("method", Method.CASH),
        customerId = if (j.isNull("customer_id")) null else j.lng("customer_id"), note = j.str("note"),
        voided = j.optBoolean("voided", false), createdByName = j.str("created_by_name"), createdBy = j.str("created_by")
    )

    /** Newest first. Employees only ever receive their own sales from the last 2 days. */
    fun recentSales(limit: Int): Flow<List<Sale>> = live(30_000L) {
        api.get("sales", "select=*&order=time.desc&limit=$limit").objs().map { parseSale(it) }
    }

    suspend fun saleItems(saleId: Long): List<SaleItem> = io {
        api.get("sale_items", "select=*&sale_id=eq.$saleId&order=id").objs().map {
            SaleItem(it.lng("id"), saleId, it.lng("product_id"), it.str("name"), it.dbl("qty"), it.dbl("unit_price"))
        }
    }

    suspend fun customerName(id: Long?): String? {
        if (id == null) return null
        customerCache.firstOrNull { it.id == id }?.let { return it.name }
        return try {
            loadCustomers().firstOrNull { it.id == id }?.name
        } catch (e: Exception) {
            null
        }
    }

    fun productNameTaken(name: String, exceptId: Long): Boolean =
        productCache.any { it.id != exceptId && it.name.trim().equals(name.trim(), ignoreCase = true) }

    // ---------------------------------------------------------------- products (owner)
    suspend fun saveProduct(p: Product): Long = change {
        api.rpcLong(
            "save_product", JSONObject().put("p_id", if (p.id == 0L) JSONObject.NULL else p.id).put("p_name", p.name.trim())
                .put("p_category", p.category).put("p_unit", p.unit).put("p_cost", p.costPrice).put("p_sell", p.sellPrice)
                .put("p_qty", p.stockQty).put("p_reorder", p.reorderLevel)
        )
    }

    suspend fun archiveProduct(id: Long) = change { api.rpc("archive_product", JSONObject().put("p_id", id)); Unit }

    suspend fun importRows(rows: List<ImportRow>): Pair<Int, Int> = change {
        var added = 0
        var updated = 0
        for (chunk in rows.chunked(150)) {
            val arr = JSONArray()
            for (r in chunk) {
                arr.put(
                    JSONObject().put("name", r.name).put("category", r.category).put("unit", r.unit)
                        .put("cost", r.cost ?: JSONObject.NULL).put("sell", r.sell ?: JSONObject.NULL)
                        .put("qty", r.qty ?: JSONObject.NULL).put("reorder", r.reorder ?: JSONObject.NULL)
                )
            }
            val res = api.rpcObject("import_products", JSONObject().put("p_rows", arr))
            added += res.optInt("added")
            updated += res.optInt("updated")
        }
        Pair(added, updated)
    }

    // ---------------------------------------------------------------- selling
    suspend fun checkout(lines: List<CartLine>, method: String, customerId: Long?, note: String): Long = change {
        val arr = JSONArray()
        for (l in lines) arr.put(JSONObject().put("product_id", l.product.id).put("qty", l.qty).put("price", l.price))
        api.rpcLong(
            "create_sale", JSONObject().put("p_lines", arr).put("p_method", method)
                .put("p_customer", customerId ?: JSONObject.NULL).put("p_note", note)
        )
    }

    suspend fun voidSale(id: Long) = change { api.rpc("void_sale", JSONObject().put("p_id", id)); Unit }

    // ---------------------------------------------------------------- stock
    suspend fun restock(productId: Long, qty: Double, unitCost: Double, supplier: String, paidNow: Double) = change {
        api.rpc(
            "restock", JSONObject().put("p_product", productId).put("p_qty", qty).put("p_unit_cost", unitCost)
                .put("p_supplier", supplier.trim()).put("p_paid_now", paidNow)
        )
        Unit
    }

    /** qtyChange is negative when stock is lost. Employees may only remove stock. */
    suspend fun adjust(productId: Long, qtyChange: Double, reason: String) = change {
        api.rpc("adjust_stock", JSONObject().put("p_product", productId).put("p_qty_change", qtyChange).put("p_reason", reason))
        Unit
    }

    // ---------------------------------------------------------------- money in/out
    suspend fun addExpense(category: String, amount: Double, note: String) = change {
        api.rpc("add_expense", JSONObject().put("p_category", category).put("p_amount", amount).put("p_note", note)); Unit
    }

    suspend fun deleteExpense(e: Expense) = change { api.rpc("delete_expense", JSONObject().put("p_id", e.id)); Unit }

    suspend fun addOwnerTxn(amount: Double, note: String) = change {
        api.rpc("add_owner_txn", JSONObject().put("p_amount", amount).put("p_note", note)); Unit
    }

    suspend fun deleteOwnerTxn(t: OwnerTxn) = change { api.rpc("delete_owner_txn", JSONObject().put("p_id", t.id)); Unit }

    suspend fun addCustomer(name: String, phone: String): Long = change {
        api.rpcLong("add_customer", JSONObject().put("p_name", name.trim()).put("p_phone", phone.trim()))
    }

    suspend fun receivePayment(customerId: Long, amount: Double) = change {
        api.rpc("receive_payment", JSONObject().put("p_customer", customerId).put("p_amount", amount)); Unit
    }

    suspend fun paySupplier(supplier: String, amount: Double) = change {
        api.rpc("pay_supplier", JSONObject().put("p_supplier", supplier).put("p_amount", amount)); Unit
    }

    suspend fun customerBalances(): List<CustomerBalance> = io {
        api.rpcObject("balances").getJSONArray("customers").objs()
            .map { CustomerBalance(Customer(it.lng("id"), it.str("name"), it.str("phone")), it.dbl("owed")) }
            .sortedByDescending { it.owed }
    }

    suspend fun supplierBalances(): List<NameAmount> = io {
        api.rpcObject("balances").getJSONArray("suppliers").objs().map { NameAmount(it.str("name"), it.dbl("owed")) }
    }

    // ---------------------------------------------------------------- shop and staff (owner)
    suspend fun updateShop(name: String, symbol: String, opening: Double, allowCredit: Boolean) {
        api.rpc(
            "update_shop", JSONObject().put("p_name", name).put("p_symbol", symbol).put("p_opening", opening)
                .put("p_allow_credit", allowCredit)
        )
        reloadShop()
    }

    suspend fun saveLicenseKey(key: String) {
        api.rpc("set_license_key", JSONObject().put("p_key", key))
        reloadShop()
    }

    suspend fun reloadShop() {
        val cur = shopState.value ?: return
        val s = fetchShop(api, cur.id)
        attach(s, isOwner)
    }

    suspend fun members(): List<MemberInfo> = io {
        api.get("members", "select=*&order=created_at").objs().map { parseMember(it) }
    }

    suspend fun setMemberActive(userId: String, active: Boolean) {
        api.rpc("set_member_active", JSONObject().put("p_user", userId).put("p_active", active))
    }

    suspend fun activity(limit: Int = 200): List<ActivityEntry> = io {
        api.get("activity_log", "select=*&order=time.desc&limit=$limit").objs()
            .map { ActivityEntry(it.lng("id"), it.lng("time"), it.str("user_name"), it.str("action"), it.str("detail")) }
    }

    // ---------------------------------------------------------------- reports (owner)
    private fun lines(arr: JSONArray): List<SaleLine> = arr.objs().map {
        SaleLine(
            saleId = it.lng("sale_id"), productId = it.lng("product_id"), name = it.str("name"), qty = it.dbl("qty"),
            unitPrice = it.dbl("unit_price"), unitCost = it.dbl("unit_cost"), saleTime = it.lng("time"),
            method = it.str("method"), staff = it.str("staff")
        )
    }

    private fun names(arr: JSONArray): List<NameAmount> = arr.objs().map { NameAmount(it.str("name"), it.dbl("amount")) }

    private fun range(r: TimeRange) = JSONObject().put("p_from", r.start).put("p_to", r.end)

    suspend fun bundle(period: Period): ReportBundle = coroutineScope {
        val now = api.now()
        val range = period.range(now)
        val prevRange = period.previousRange(now)
        val last30From = now - 30L * 24 * 3600 * 1000

        val curLines = async(Dispatchers.IO) { lines(api.rpcArray("report_lines", range(range))) }
        val prevLines = async(Dispatchers.IO) { lines(api.rpcArray("report_lines", range(prevRange))) }
        val last30 = async(Dispatchers.IO) { lines(api.rpcArray("report_lines", range(TimeRange(last30From, now + 1)))) }
        val sums = async(Dispatchers.IO) { api.rpcObject("report_sums", range(range)) }
        val bal = async(Dispatchers.IO) { api.rpcObject("balances") }
        val prods = async(Dispatchers.IO) { loadProducts() }

        val s = sums.await()
        val l = curLines.await()
        val products = prods.await()
        val b = bal.await()

        val raw = RawData(
            range = range, lines = l, salesByMethod = names(s.getJSONArray("sales_by_method")),
            expenses = names(s.getJSONArray("expenses")),
            losses = names(s.getJSONArray("losses")).filter { abs(it.amount) > 0.0001 },
            restockPaid = s.dbl("restock_paid"), restockTotal = s.dbl("restock_total"),
            supplierPaid = s.dbl("supplier_paid"), customerPaid = s.dbl("customer_paid"),
            ownerIn = s.dbl("owner_in"), ownerOut = s.dbl("owner_out"), openingMoney = s.dbl("opening_money")
        )
        val debtors = b.getJSONArray("customers").objs()
            .filter { abs(it.dbl("owed")) > 0.005 }.map { NameAmount(it.str("name"), it.dbl("owed")) }.sortedByDescending { it.amount }
        val creditors = b.getJSONArray("suppliers").objs().map { NameAmount(it.str("name"), it.dbl("owed")) }
        val position = Position(
            money = s.dbl("money_now"), stockValue = Engine.stockValue(products), debtors = debtors, creditors = creditors
        )
        val stats = Engine.productStats(l)
        val kind = Engine.bucketKind(period)
        ReportBundle(
            period = period, range = range, raw = raw, summary = Engine.summary(l), prev = Engine.summary(prevLines.await()),
            stats = stats, trend = Engine.trend(l, range, kind), trendKind = kind, products = products,
            notSelling = Engine.notSelling(products, stats), reorder = Engine.reorder(products, last30.await()),
            position = position, busiestHour = Engine.busiestHour(l), bestWeekday = Engine.bestWeekday(l)
        )
    }

    companion object {
        fun parseMember(j: JSONObject) = MemberInfo(
            userId = j.str("user_id"), role = if (j.str("role") == "owner") Role.OWNER else Role.EMPLOYEE,
            username = j.str("username"), displayName = j.str("display_name"), active = j.optBoolean("active", true)
        )

        fun parseShop(j: JSONObject) = ShopInfo(
            id = j.str("id"), code = j.str("code"), name = j.str("name"), symbol = j.str("symbol", "$"),
            openingMoney = j.dbl("opening_money"), licenseKey = if (j.isNull("license_key")) null else j.str("license_key"),
            allowEmployeeCredit = j.optBoolean("allow_employee_credit", true),
            migratedAt = if (j.isNull("migrated_at")) null else j.lng("migrated_at"), createdAt = j.lng("created_at")
        )

        suspend fun fetchShop(api: Api, id: String): ShopInfo {
            val rows = api.get("shops", "select=*&id=eq.$id")
            if (rows.length() == 0) throw ApiException("Shop not found.")
            return parseShop(rows.getJSONObject(0))
        }
    }
}
