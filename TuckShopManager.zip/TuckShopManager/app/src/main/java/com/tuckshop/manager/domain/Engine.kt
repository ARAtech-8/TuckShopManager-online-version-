package com.tuckshop.manager.domain

import com.tuckshop.manager.data.NameAmount
import com.tuckshop.manager.data.Product
import com.tuckshop.manager.data.Restock
import com.tuckshop.manager.data.Sale
import com.tuckshop.manager.data.Customer
import com.tuckshop.manager.data.CustomerPayment
import com.tuckshop.manager.data.SaleLine
import com.tuckshop.manager.data.SupplierPayment
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

/** All the number-crunching. Pure functions, no database or Android needed. */
object Engine {

    fun summary(lines: List<SaleLine>): Summary {
        var sales = 0.0
        var cost = 0.0
        var units = 0.0
        val ids = HashSet<Long>()
        for (l in lines) {
            sales += l.qty * l.unitPrice
            cost += l.qty * l.unitCost
            units += l.qty
            ids.add(l.saleId)
        }
        return Summary(sales, cost, units, ids.size)
    }

    fun productStats(lines: List<SaleLine>): List<ProductStat> =
        lines.groupBy { it.productId }.map { (id, ls) ->
            ProductStat(
                productId = id,
                name = ls.last().name,
                qty = ls.sumOf { it.qty },
                revenue = ls.sumOf { it.qty * it.unitPrice },
                cost = ls.sumOf { it.qty * it.unitCost }
            )
        }

    fun bucketKind(p: Period): BucketKind = when (p) {
        Period.TODAY -> BucketKind.HOUR
        Period.WEEK, Period.MONTH -> BucketKind.DAY
        Period.M3 -> BucketKind.WEEK
        Period.M6, Period.Y1 -> BucketKind.MONTH
    }

    fun trend(lines: List<SaleLine>, range: TimeRange, kind: BucketKind): List<Bucket> {
        val cal = Calendar.getInstance()
        cal.timeInMillis = range.start
        val starts = ArrayList<Long>()
        while (cal.timeInMillis < range.end && starts.size < 400) {
            starts.add(cal.timeInMillis)
            when (kind) {
                BucketKind.HOUR -> cal.add(Calendar.HOUR_OF_DAY, 1)
                BucketKind.DAY -> cal.add(Calendar.DAY_OF_YEAR, 1)
                BucketKind.WEEK -> cal.add(Calendar.DAY_OF_YEAR, 7)
                BucketKind.MONTH -> {
                    cal.add(Calendar.MONTH, 1)
                    cal.set(Calendar.DAY_OF_MONTH, 1)
                }
            }
        }
        if (starts.isEmpty()) return emptyList()
        val sales = DoubleArray(starts.size)
        val profit = DoubleArray(starts.size)
        for (l in lines) {
            val i = starts.binarySearch(l.saleTime)
            val idx = if (i >= 0) i else -i - 2
            if (idx < 0 || idx >= starts.size) continue
            sales[idx] += l.qty * l.unitPrice
            profit[idx] += l.qty * (l.unitPrice - l.unitCost)
        }
        val fmt = when (kind) {
            BucketKind.HOUR -> SimpleDateFormat("ha", Locale.US)
            BucketKind.DAY, BucketKind.WEEK -> SimpleDateFormat("d MMM", Locale.US)
            BucketKind.MONTH -> SimpleDateFormat("MMM", Locale.US)
        }
        return starts.mapIndexed { i, t ->
            Bucket(fmt.format(Date(t)).lowercase(Locale.US), sales[i], profit[i])
        }
    }

    /** Hour of day (0-23) with the most sales, and how much. */
    fun busiestHour(lines: List<SaleLine>): Pair<Int, Double>? {
        if (lines.isEmpty()) return null
        val byHour = DoubleArray(24)
        val cal = Calendar.getInstance()
        for (l in lines) {
            cal.timeInMillis = l.saleTime
            byHour[cal.get(Calendar.HOUR_OF_DAY)] += l.qty * l.unitPrice
        }
        var best = 0
        for (h in 1 until 24) if (byHour[h] > byHour[best]) best = h
        return if (byHour[best] > 0.0) Pair(best, byHour[best]) else null
    }

    private val dayNames = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

    fun bestWeekday(lines: List<SaleLine>): Pair<String, Double>? {
        if (lines.isEmpty()) return null
        val byDay = DoubleArray(7)
        val cal = Calendar.getInstance()
        for (l in lines) {
            cal.timeInMillis = l.saleTime
            byDay[cal.get(Calendar.DAY_OF_WEEK) - 1] += l.qty * l.unitPrice
        }
        var best = 0
        for (d in 1 until 7) if (byDay[d] > byDay[best]) best = d
        return if (byDay[best] > 0.0) Pair(dayNames[best], byDay[best]) else null
    }

    /** Products that are on the shelf but did not sell at all in the period. */
    fun notSelling(products: List<Product>, stats: List<ProductStat>): List<Product> {
        val sold = stats.map { it.productId }.toSet()
        return products.filter { it.stockQty > 0.0 && it.id !in sold }
    }

    /** Items that are running low, with a suggested amount to buy based on the last 30 days of sales. */
    fun reorder(products: List<Product>, last30: List<SaleLine>): List<ReorderItem> {
        val soldBy = last30.groupBy { it.productId }.mapValues { e -> e.value.sumOf { it.qty } }
        return products.mapNotNull { p ->
            val perDay = (soldBy[p.id] ?: 0.0) / 30.0
            val daysLeft = if (perDay > 0.0) max(0.0, p.stockQty) / perDay else null
            val low = p.stockQty <= p.reorderLevel || (daysLeft != null && daysLeft < 3.0)
            if (!low) null
            else {
                val want = max(max(perDay * 14.0 - p.stockQty, p.reorderLevel * 2.0 - p.stockQty), 1.0)
                ReorderItem(p, daysLeft, ceil(want))
            }
        }.sortedBy { it.daysLeft ?: Double.MAX_VALUE }
    }

    /** Net money movement in a stretch of time. Used to roll the opening balance forward. */
    fun netMoney(
        salesReceived: Double, customerPaid: Double, restockPaid: Double,
        supplierPaid: Double, expenses: Double, ownerIn: Double, ownerOut: Double
    ): Double = salesReceived + customerPaid - restockPaid - supplierPaid - expenses + ownerIn - ownerOut

    /** How much each customer still owes: credit sales minus what they have paid back. */
    fun debtors(creditSales: List<Sale>, payments: List<CustomerPayment>, customers: List<Customer>): List<NameAmount> {
        val owed = HashMap<Long, Double>()
        for (s in creditSales) {
            val id = s.customerId ?: continue
            owed[id] = (owed[id] ?: 0.0) + s.total
        }
        for (p in payments) owed[p.customerId] = (owed[p.customerId] ?: 0.0) - p.amount
        val names = customers.associate { it.id to it.name }
        return owed.entries
            .filter { kotlin.math.abs(it.value) > 0.005 }
            .map { NameAmount(names[it.key] ?: "Customer", it.value) }
            .sortedByDescending { it.amount }
    }

    /** How much is still owed to each supplier: stock bought on credit minus payments made. */
    fun creditors(restocks: List<Restock>, payments: List<SupplierPayment>): List<NameAmount> {
        val owed = LinkedHashMap<String, Double>()
        val display = HashMap<String, String>()
        fun key(n: String): String {
            val k = n.trim().lowercase(Locale.US).ifEmpty { "(no supplier name)" }
            if (!display.containsKey(k)) display[k] = n.trim().ifEmpty { "Supplier (no name)" }
            return k
        }
        for (r in restocks) {
            val k = key(r.supplier)
            owed[k] = (owed[k] ?: 0.0) + (r.qty * r.unitCost - r.paidNow)
        }
        for (p in payments) {
            val k = key(p.supplier)
            owed[k] = (owed[k] ?: 0.0) - p.amount
        }
        return owed.entries
            .filter { kotlin.math.abs(it.value) > 0.005 }
            .map { NameAmount(display[it.key] ?: it.key, it.value) }
            .sortedByDescending { it.amount }
    }

    fun stockValue(products: List<Product>): Double =
        products.sumOf { max(0.0, it.stockQty) * it.costPrice }
}
