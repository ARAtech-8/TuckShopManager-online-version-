package com.tuckshop.manager.domain

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Licence keys. A key belongs to one shop: it is a signature (HMAC) of the shop's code, so it only unlocks that shop.
 * Once entered by the owner it is saved with the shop, so every phone signed in to the shop is unlocked.
 */
object License {
    const val WHATSAPP = "263715048687"
    const val WHATSAPP_DISPLAY = "+263 715 048 687"
    const val TRIAL_MS = 24L * 60 * 60 * 1000

    // Must be identical to the secret inside keygen.html. Keep both private.
    private const val SECRET = "a0df32d6f84d4b6b615064145cd7ed5e"
    private const val ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"

    private fun base32(bytes: ByteArray, chars: Int): String {
        val sb = StringBuilder()
        var buf = 0
        var bits = 0
        var i = 0
        while (sb.length < chars) {
            if (bits < 5) {
                buf = (buf shl 8) or (bytes[i++].toInt() and 0xFF)
                bits += 8
            }
            bits -= 5
            sb.append(ALPHABET[(buf shr bits) and 31])
            buf = buf and ((1 shl bits) - 1)
        }
        return sb.toString()
    }

    private fun group(s: String): String = s.chunked(4).joinToString("-")

    fun normalize(s: String): String = s.uppercase().filter { it.isLetterOrDigit() }

    private fun mac(text: String): String {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(SECRET.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return group(base32(m.doFinal(text.toByteArray(Charsets.UTF_8)), 16))
    }

    /** One key per shop: it is a signature of the shop's 6-character code. */
    fun keyForShop(shopCode: String): String = mac("TSM2|" + normalize(shopCode))

    fun isValid(shopCode: String, key: String): Boolean {
        val want = normalize(keyForShop(shopCode))
        val got = normalize(key)
        if (want.length != got.length) return false
        var diff = 0
        for (i in want.indices) diff = diff or (want[i].code xor got[i].code)
        return diff == 0
    }
}
