package com.tuckshop.manager.legacy

import androidx.room.Dao
import androidx.room.Query

/** Read-only access to the records the old (phone-only) version stored. Used once, to move them to the cloud. */
@Dao
interface LegacyDao {
    @Query("SELECT * FROM products") suspend fun products(): List<LegacyProduct>
    @Query("SELECT * FROM customers") suspend fun customers(): List<LegacyCustomer>
    @Query("SELECT * FROM sales ORDER BY time") suspend fun sales(): List<LegacySale>
    @Query("SELECT * FROM sale_items") suspend fun saleItems(): List<LegacySaleItem>
    @Query("SELECT * FROM restocks") suspend fun restocks(): List<LegacyRestock>
    @Query("SELECT * FROM supplier_payments") suspend fun supplierPayments(): List<LegacySupplierPayment>
    @Query("SELECT * FROM adjustments") suspend fun adjustments(): List<LegacyAdjustment>
    @Query("SELECT * FROM expenses") suspend fun expenses(): List<LegacyExpense>
    @Query("SELECT * FROM owner_txns") suspend fun ownerTxns(): List<LegacyOwnerTxn>
    @Query("SELECT * FROM customer_payments") suspend fun customerPayments(): List<LegacyCustomerPayment>
}
